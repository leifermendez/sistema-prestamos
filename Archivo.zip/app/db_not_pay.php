<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class db_not_pay extends Model
{
    protected $table = 'not_pay';
    public $timestamps = false;
}
