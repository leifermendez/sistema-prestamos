<?php $__env->startSection('content'); ?>
    <!-- APP MAIN ==========-->
    <main id="app-main" class="app-main">
        <div class="wrap">
            <section class="app-content">
                <div class="row">
                    <div class="col-md-12">
                        <div class="widget p-lg">
                            <h4 class="m-b-lg">Creditos Otorgados</h4>
                            <table class="table supervisor-editC-table">
                                <tbody>
                                <tr>
                                    <th>Nombres</th>
                                    <th>Credito</th>
                                    <th>Barrio</th>
                                    <th>Hora</th>
                                    <th>Tasa</th>
                                    <th>Cuotas</th>
                                    <th>Valor</th>
                                    <th></th>
                                </tr>
                                <?php $__currentLoopData = $credit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cred): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><span class="value"><?php echo e($cred->name); ?> <?php echo e($cred->last_name); ?></span></td>
                                        <td><span class="value"><?php echo e($cred->credit_id); ?></span></td>
                                        <td><span class="value"><?php echo e($cred->province); ?></span></td>
                                        <td><span class="value"><?php echo e($cred->created_at); ?></span></td>
                                        <td><span class="value"><?php echo e($cred->utility); ?></span></td>
                                        <td><span class="value"><?php echo e($cred->payment_number); ?></span></td>
                                        <td><span class="value"><?php echo e($cred->amount_neto); ?></span></td>
                                        <td class="text-right">
                                            <a href="<?php echo e(url('supervisor/credit')); ?>/<?php echo e($cred->credit_id); ?>/edit?id_wallet=<?php echo e($id_wallet); ?>" class="btn btn-xs btn-warning">Editar</a>
                                        </td>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody></table>
                        </div><!-- .widget -->
                    </div>
                </div><!-- .row -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="widget p-lg">
                            <h4 class="m-b-lg">Gastos del Agente</h4>
                            <table class="table supervisor-editG-table">
                                <tbody>
                                <tr>
                                    <th>Gasto</th>
                                    <th>Detalle</th>
                                    <th>Valor</th>
                                    <th></th>
                                </tr>
                                <?php $__currentLoopData = $bills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><span class="value"><?php echo e($bill->type); ?></span></td>
                                        <td><span class="value"><?php echo e($bill->description); ?></span></td>
                                        <td><span class="value"><?php echo e($bill->amount); ?></span></td>
                                        <td class="text-right">
                                            <a href="<?php echo e(url('supervisor/bill')); ?>/<?php echo e($bill->id); ?>/edit?id_wallet=<?php echo e($id_wallet); ?>" class="btn btn-xs btn-warning">Editar</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody></table>
                        </div><!-- .widget -->
                    </div>
                </div><!-- .row -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="widget p-lg">
                            <h4 class="m-b-lg">Pagos Recibidos</h4>
                            <table class="table supervisor-editP-table">
                                <tbody>
                                <tr>
                                    <th>Nombres</th>
                                    <th>Credito</th>
                                    <th>Cuota</th>
                                    <th>Valor</th>
                                    <th>Saldo</th>
                                    <th></th>
                                </tr>
                                <?php $__currentLoopData = $summary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><span class="value"><?php echo e($sum->name); ?> <?php echo e($sum->last_name); ?></span></td>
                                        <td><span class="value"><?php echo e($sum->id_credit); ?></span></td>
                                        <td><span class="value"><?php echo e($sum->number_index); ?></span></td>
                                        <td><span class="value"><?php echo e($sum->amount); ?></span></td>
                                        <td><span class="value"><?php echo e(($sum->amount_neto)-($sum->total_payment)); ?></span></td>
                                        <td class="text-right">
                                            <a href="<?php echo e(url('supervisor/summary')); ?>/<?php echo e($cred->credit_id); ?>/edit?id_wallet=<?php echo e($id_wallet); ?>" class="btn btn-xs btn-warning">Editar</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody></table>
                        </div><!-- .widget -->
                    </div>
                </div><!-- .row -->
            </section>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>