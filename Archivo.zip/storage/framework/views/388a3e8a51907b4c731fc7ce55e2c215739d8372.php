<?php $__env->startSection('content'); ?>
    <!-- APP MAIN ==========-->
    <main id="app-main" class="app-main">
        <div class="wrap">
            <section class="app-content">
                <div class="row">
                    <div class="col-md-12">
                        <div class="widget p-lg">
                            <h4 class="m-b-lg">Clientes y Creditos</h4>
                            <table class="table agente-payments-table">
                                <tbody>
                                <tr>
                                    <th>Nombres</th>
                                    <th>Credito</th>
                                    <th>Valor</th>
                                    <th>Saldo</th>
                                    <th>Cuota</th>
                                    <th></th>
                                </tr>
                                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($client->name); ?> <?php echo e($client->last_name); ?></td>
                                        <td><?php echo e($client->credit_id); ?></td>
                                        <td><?php echo e($client->amount_neto); ?></td>
                                        <td><?php echo e($client->positive); ?></td>
                                        <td><?php echo e($client->payment_current); ?> / <?php echo e($client->payment_number); ?></td>
                                        <td>
                                            <a href="<?php echo e(url('payment')); ?>/<?php echo e($client->credit_id); ?>" class="btn btn-success btn-xs"><i class="fa fa-money"></i> Pagar</a>
                                            <a href="<?php echo e(url('summary')); ?>?id_credit=<?php echo e($client->credit_id); ?>" class="btn btn-info btn-xs"><i class="fa fa-history"></i> Ver</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody></table>
                        </div><!-- .widget -->
                    </div>
                </div><!-- .row -->
            </section>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>