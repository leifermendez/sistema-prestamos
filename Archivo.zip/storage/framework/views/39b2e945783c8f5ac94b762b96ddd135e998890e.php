<?php $__env->startSection('content'); ?>
    <!-- APP MAIN ==========-->
    <main id="app-main" class="app-main">
        <div class="wrap">
            <section class="app-content">
                <div class="row">
                    <div class="col-md-12">
                        <div class="widget p-lg">
                            <h4 class="m-b-lg">Clientes y Creditos</h4>
                            <table class="table agente-route-table">
                                <tbody>
                                <tr>
                                    <th>Credito</th>
                                    <th>Nombres</th>
                                    <th>Días en mora</th>
                                    <th>Cuato diaria</th>
                                    <th>Valor</th>
                                    <th>Saldo</th>
                                    <th>Ultimo pago</th>
                                    <th>Barrio</th>
                                    <th>Status</th>
                                    <th></th>
                                </tr>
                                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($client->id); ?></td>
                                        <td><?php echo e($client->user->name); ?> <?php echo e($client->user->last_name); ?></td>
                                        <td><?php echo e($client->days_rest); ?></td>
                                        <td><?php echo e($client->quote); ?></td>
                                        <td><?php echo e($client->amount_total); ?></td>
                                        <td><?php echo e($client->saldo); ?></td>
                                        <?php if($client->last_pay): ?>
                                            <td><?php echo e($client->last_pay); ?></td>
                                        <?php else: ?>
                                            <td>No hay pagos</td>
                                        <?php endif; ?>
                                        <td><?php echo e($client->user->province); ?></td>
                                        <td>
                                            <?php if($client->user->status=='good'): ?>
                                                <span class="badge-info badge">BUENO</span>
                                            <?php elseif($client->user->status=='bad'): ?>
                                                <span class="badge-danger badge">MALO</span>
                                            <?php endif; ?>

                                        </td>
                                        <td>
                                            <a href="<?php echo e(url('payment')); ?>/<?php echo e($client->id_user); ?>/edit?id_credit=<?php echo e($client->id); ?>" class="btn btn-warning btn-xs"><i class="fa fa-archive"></i> Saltar</a>
                                            <a href="<?php echo e(url('payment')); ?>/<?php echo e($client->id); ?>" class="btn btn-success btn-xs"><i class="fa fa-money"></i> Pagar</a>
                                            <a href="<?php echo e(url('summary')); ?>?id_credit=<?php echo e($client->id); ?>" class="btn btn-info btn-xs"><i class="fa fa-history"></i> Ver</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody></table>
                        </div><!-- .widget -->
                    </div>
                </div><!-- .row -->
            </section>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>