<?php $__env->startSection('content'); ?>
    <!-- APP MAIN ==========-->
    <main id="app-main" class="app-main">
        <div class="wrap">
            <section class="app-content">
                <div class="row">
                    <div class="col-md-12">
                        <div class="widget p-lg">
                            <h4 class="m-b-lg">Movimientos desde hasta</h4>
                            <table class="table supervisor-done-table">
                                <tbody>
                                <tr>
                                    <th>ID Credito</th>
                                    <th>Nombre</th>
                                    <th>Fecha Prestamo</th>
                                    <th>Capital</th>
                                    <th>Tasa</th>
                                    <th>Interes</th>
                                    <th>Cuotas</th>
                                    <th>Ultimo Pago</th>
                                    <th>Valor Pago</th>
                                    <th># Pagos</th>

                                </tr>
                                <?php $__currentLoopData = $credit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cred): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><span class="value"><?php echo e($cred->credit_id); ?></span></td>
                                        <td><span class="value"><?php echo e($cred->name); ?> <?php echo e($cred->last_name); ?></span></td>
                                        <td><span class="value"><?php echo e($cred->credit_date); ?></span></td>
                                        <td><span class="value"><?php echo e($cred->amount_neto); ?></span></td>
                                        <td><span class="value"><?php echo e($cred->utility); ?></span></td>
                                        <td><span class="value"><?php echo e(($cred->amount_neto)*($cred->utility)); ?></span></td>
                                        <td><span class="value"><?php echo e($cred->payment_number); ?></span></td>
                                        <td><span class="value"><?php echo e($cred->summary_lasted); ?></span></td>
                                        <td><span class="value"><?php echo e($cred->summary_amount); ?></span></td>
                                        <td><span class="value"><?php echo e($cred->summary_number_pay); ?></span></td>


                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody></table>
                        </div><!-- .widget -->
                    </div>
                </div><!-- .row -->
            </section>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>