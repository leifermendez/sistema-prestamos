<?php $__env->startSection('content'); ?>
    <!-- APP MAIN ==========-->
    <main id="app-main" class="app-main">
        <div class="wrap">
            <section class="app-content">
                <div class="row">
                    <div class="col-md-12">

                        <div class="widget p-lg">
                            <h4 class="m-b-lg">Consulta de Gastos</h4>
                            <form class="form-inline" method="GET" <?php echo e(url('supervisor/bill')); ?>>
                                <div class="form-group">
                                    <label for="email">Feacha Inicio:</label>
                                    <input type="text" class="form-control datepicker-trigger" name="date_start" id="date_start">
                                </div>
                                <div class="form-group">
                                    <label for="pwd">Fecha Final:</label>
                                    <input type="text" class="form-control datepicker-trigger" name="date_end" id="pwd">
                                </div>
                                <button type="submit" class="btn btn-success">Buscar</button>
                            </form>
                            <br class="clearfix">
                            <table class="table supervisor-billS-table">
                                <tbody>
                                <tr>
                                    <th>Fecha</th>
                                    <th>Cartera</th>
                                    <th>Gasto</th>
                                    <th>Valor</th>
                                    <th>Detalle</th>
                                </tr>
                                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($client->created_at); ?></td>
                                        <td><?php echo e($client->wallet_name); ?></td>
                                        <td><?php echo e($client->type); ?></td>
                                        <td><?php echo e($client->amount); ?></td>
                                        <td><?php echo e($client->description); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody></table>
                            <footer class="widget-footer">
                                <p class="text-success"><b>Total: </b> <?php echo e($sum); ?></p>
                            </footer>
                        </div><!-- .widget -->

                    </div>
                </div><!-- .row -->
            </section>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>