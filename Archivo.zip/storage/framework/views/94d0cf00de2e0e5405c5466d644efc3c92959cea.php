<?php $__env->startSection('content'); ?>
    <!-- APP MAIN ==========-->
    <main id="app-main" class="app-main">
        <div class="wrap">
            <section class="app-content">
                <div class="row">
                    <div class="col-md-12">
                        <div class="widget p-lg">
                            <h4 class="m-b-lg">Agentes</h4>
                            <table class="table supervisor-agent-table">
                                <tbody>
                                <tr>
                                    <th>Nombre</th>
                                    <th>Cartera</th>
                                    <th>Pais</th>
                                    <th>Ciudad</th>
                                    <th>Base</th>
                                    <th>Accion</th>
                                </tr>
                                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><span class="value"><?php echo e($client->name); ?> <?php echo e($client->last_name); ?></span></td>
                                        <td><span class="value"><?php echo e($client->wallet_name); ?></span></td>
                                        <td><span class="value"><?php echo e($client->country); ?></span></td>
                                        <td><span class="value"><?php echo e($client->address); ?></span></td>
                                        <td><span class="value"><?php echo e($client->base_total); ?></span></td>
                                        <td>
                                            <a href="<?php echo e(url('supervisor/agent')); ?>/<?php echo e($client->id); ?>/edit" class="btn btn-success btn-xs">Base</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody></table>
                        </div><!-- .widget -->
                    </div>
                </div><!-- .row -->
            </section>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>