<?php $__env->startSection('content'); ?>
    <!-- APP MAIN ==========-->
    <main id="app-main" class="app-main">
        <div class="wrap">
            <section class="app-content">
                <div class="row">
                    <div class="col-md-12 col-lg-8 col-lg-offset-2">
                        <div class="widget">
                            <header class="widget-header">
                                <h4 class="widget-title">Cierre</h4>
                            </header><!-- .widget-header -->
                            <hr class="widget-separator">
                            <div class="widget-body">
                                <form method="GET" action="<?php echo e(url('history')); ?>" enctype="multipart/form-data">
                                    <div class="form-group">
                                        <label for="base_amount">Base del cobro:</label>
                                        <input type="text" name="base_amount" value="<?php echo e($base); ?>" readonly class="form-control" id="base_amount" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="base_amount">Recaudo:</label>
                                        <input type="text" name="today" value="<?php echo e($today_amount); ?>" readonly class="form-control" id="base_amount" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="base_amount">Ventas:</label>
                                        <input type="text" name="today" value="<?php echo e($today_sell); ?>" readonly class="form-control" id="base_amount" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="base_amount">Gastos:</label>
                                        <input type="text" name="today" value="<?php echo e($bills); ?>" readonly class="form-control" id="base_amount" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="base_amount">Total Cuadre:</label>
                                        <input type="text" name="today" value="<?php echo e($total); ?>" readonly class="form-control" id="base_amount" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="base_amount">Efectividad:</label>
                                        <input type="text" name="today" value="<?php echo e($average); ?>" readonly class="form-control" id="base_amount" required>
                                    </div>
                                </form>

                            </div><!-- .widget-body -->
                        </div><!-- .widget -->
                    </div><!-- END column -->
                </div><!-- .row -->
            </section>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>