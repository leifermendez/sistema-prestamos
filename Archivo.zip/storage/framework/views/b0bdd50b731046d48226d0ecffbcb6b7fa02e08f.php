<?php $__env->startSection('content'); ?>
    <!-- APP MAIN ==========-->
    <main id="app-main" class="app-main">
        <div class="wrap">
            <section class="app-content">
                <div class="row">
                    <div class="col-md-12">
                        <div class="widget p-lg">
                            <h4 class="m-b-lg">Movimientos desde hasta</h4>
                            <table class="table supervisor-report-table">
                                <tbody>
                                <tr>
                                    <th>Fecha cierre</th>
                                    <th>Base</th>
                                    <th>Recaudo</th>
                                    <th>Creditos</th>
                                    <th>Gasto Agente</th>
                                    <th>Cierre</th>
                                    <th>% Diario</th>
                                    <th>Valor Cartera</th>

                                </tr>
                                <?php $__currentLoopData = $credit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cred): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><span class="value"><?php echo e($cred->created_at); ?></span></td>
                                        <td><span class="value"><?php echo e($cred->base_before); ?></span></td>
                                        <td><span class="value"><?php echo e($cred->summary_total); ?></span></td>
                                        <td><span class="value"><?php echo e($cred->credit_total); ?></span></td>
                                        <td><span class="value"><?php echo e($cred->bills_total); ?></span></td>
                                        <td><span class="value"><?php echo e($cred->total_day); ?></span></td>
                                        <td><span class="value"><?php echo e($cred->credit_utility); ?></span></td>
                                        <td><span class="value"><?php echo e($cred->base_wallet); ?></span></td>


                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody></table>
                        </div><!-- .widget -->
                    </div>
                </div><!-- .row -->
            </section>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>