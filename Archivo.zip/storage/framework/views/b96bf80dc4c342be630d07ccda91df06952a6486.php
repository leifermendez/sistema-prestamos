<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta name="description" content="Admin, Dashboard, Bootstrap" />
    <link rel="shortcut icon" sizes="196x196" href="../assets/images/logo.png">
    <title><?php echo e(config("app.name")); ?></title>

    <link rel="stylesheet" href="<?php echo e(asset('libs/bower/font-awesome/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('libs/bower/material-design-iconic-font/dist/css/material-design-iconic-font.css')); ?>">
    <!-- build:css ../assets/css/app.min.css -->
    <link rel="stylesheet" href="<?php echo e(asset('libs/bower/animate.css/animate.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('libs/bower/fullcalendar/dist/fullcalendar.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('libs/bower/perfect-scrollbar/css/perfect-scrollbar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/dropzone.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/core.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/jquery-ui.css')); ?>">
    <meta name="theme-color" content="#42A5F5">

    <!-- endbuild -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway:400,500,600,700,800,900,300">
    <script src="<?php echo e(asset('libs/bower/breakpoints.js/dist/breakpoints.min.js')); ?>"></script>
    <script>
        Breakpoints();
    </script>
</head>

<body class="theme-primary menubar-light pace-done menubar-top">
<!--============= start main area -->
<?php echo $__env->make('layout.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('layout.navbarsearch', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->yieldContent('content'); ?>

<?php echo $__env->make('layout.sidepanel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>

<?php echo $__env->make('layout.script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</html>
