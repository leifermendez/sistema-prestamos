<nav id="app-navbar" class="navbar navbar-inverse navbar-fixed-top primary in">

    <!-- navbar header -->
    <div class="navbar-header">
        <a href="{{url('/home')}}" class="navbar-toggle visible-xs-inline-block navbar-toggle-left hamburger hamburger--collapse js-hamburger">
            <span class="sr-only">Toggle navigation</span>
            <span class="hamburger-box"><i class="fa fa-home fa-2x"></i></span>
        </a>

        <a href="{{url('logout')}}" class="navbar-toggle navbar-toggle-right collapsed" data-toggle="collapse" data-target="#app-navbar-collapse" aria-expanded="false">
            <i class="fa fa-sign-out fa-2x"></i>
        </a>



        <a href="{{url('home')}}" class="navbar-brand">
            <span class="brand-icon">{{Auth::user()->name}}</span>
        </a>
    </div><!-- .navbar-header -->

    <div class="navbar-container container-fluid">
        <div class="collapse navbar-collapse" id="app-navbar-collapse">
            <ul class="nav navbar-toolbar navbar-toolbar-right navbar-right">
                <li class="nav-item dropdown hidden-float">
                    <a href="{{url('logout')}}">
                        <i class="fa fa-sign-out fa-2x"></i>
                    </a>
                </li>
            </ul>
            <div class="app-user">
                <div class="media">
                    <div class="media-left">
                        <div class="avatar avatar-md avatar-circle dropdown">
                            <a href="javascript:void(0)" data-toggle="dropdown"><img class="img-responsive" src="../assets/images/221.jpg" alt="avatar"></a>
                            <ul class="dropdown-menu animated flipInY">
                                <li>
                                    <a class="text-color" href="/index.html">
                                        <span class="m-r-xs"><i class="fa fa-home"></i></span>
                                        <span>Home</span>
                                    </a>
                                </li>
                                <li>
                                    <a class="text-color" href="profile.html">
                                        <span class="m-r-xs"><i class="fa fa-user"></i></span>
                                        <span>Profile</span>
                                    </a>
                                </li>
                                <li>
                                    <a class="text-color" href="settings.html">
                                        <span class="m-r-xs"><i class="fa fa-gear"></i></span>
                                        <span>Settings</span>
                                    </a>
                                </li>
                                <li role="separator" class="divider"></li>
                                <li>
                                    <a class="text-color" href="logout.html">
                                        <span class="m-r-xs"><i class="fa fa-power-off"></i></span>
                                        <span>Home</span>
                                    </a>
                                </li>
                            </ul></div><!-- .avatar -->
                    </div>
                    <div class="media-body">
                        <div class="foldable">
                            <h5><a href="javascript:void(0)" class="username">John Doe</a></h5>
                            <ul>
                                <li class="dropdown">
                                    <a href="javascript:void(0)" class="dropdown-toggle usertitle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <small>Web Developer</small>
                                        <span class="caret"></span>
                                    </a>
                                    <ul class="dropdown-menu animated flipInY">
                                        <li>
                                            <a class="text-color" href="/index.html">
                                                <span class="m-r-xs"><i class="fa fa-home"></i></span>
                                                <span>Home</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a class="text-color" href="profile.html">
                                                <span class="m-r-xs"><i class="fa fa-user"></i></span>
                                                <span>Profile</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a class="text-color" href="settings.html">
                                                <span class="m-r-xs"><i class="fa fa-gear"></i></span>
                                                <span>Settings</span>
                                            </a>
                                        </li>
                                        <li role="separator" class="divider"></li>
                                        <li>
                                            <a class="text-color" href="logout.html">
                                                <span class="m-r-xs"><i class="fa fa-power-off"></i></span>
                                                <span>Home</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div><!-- .media-body -->
                </div><!-- .media -->
            </div></div>
    </div><!-- navbar-container -->
</nav>
