<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class db_agent_has_user extends Model
{
    protected $table = 'agent_has_client';
    public $timestamps = false;
}
