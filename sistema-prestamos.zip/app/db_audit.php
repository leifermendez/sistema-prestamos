<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class db_audit extends Model
{
    protected $table = 'audit';
}
