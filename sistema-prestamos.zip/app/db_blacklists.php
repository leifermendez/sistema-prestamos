<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class db_blacklists extends Model
{
    protected $table = 'blacklists';
//    public $timestamps = false;
}