<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class db_credit extends Model
{
    protected $table = 'credit';
}
