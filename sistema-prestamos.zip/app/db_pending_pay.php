<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class db_pending_pay extends Model
{
protected $table = 'pending_pays';
}
