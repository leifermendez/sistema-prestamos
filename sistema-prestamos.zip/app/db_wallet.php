<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class db_wallet extends Model
{
    protected $table = 'wallet';
    public $timestamps = false;
}
