

<?php $__env->startSection('content'); ?>
    <!-- APP MAIN ==========-->
    <main id="app-main" class="app-main">
        <div class="wrap">
            <section class="app-content">
                <div class="d-flex flex-wrap justify-content-center">
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="widget m-2 stats-widget widget-resume">
                            <div class="widget-body clearfix h-100 bg-white">
                                <div class="pull-left">
                                    <h3 class="widget-title text-dark"><?php echo e($item->name); ?></h3>
                                    <h3 class="widget-title text-dark">DISPONIBLE (CAJA)</h3>
                                    <h3 class="widget-title text-dark">
                                        <h5> + Base Inicial = <span class=""> <?php echo e($item->base_final); ?></span>
                                            <h5> + Cobrado = <span class=""> <?php echo e($item->total_summary); ?></span>
                                                <h5> - Prestado = <?php echo e($item->base_credit); ?></h5>
                                                <h5> - Gastos = <?php echo e($item->total_bill); ?> </h5>
                                                <h5> ---------------------</h5>
                                                <h5 class="text-success"> Caja = <?php echo e(($item->base_agent - $item->total_bill) + $item->total_summary); ?></h5>
                                    </h3>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\artur\Desktop\TRABAJOS\SISTEMA-PRESTAMO\sistema-prestamos\resources\views/daily-report/index.blade.php ENDPATH**/ ?>