

<?php $__env->startSection('content'); ?>
    <!-- APP MAIN ==========-->
    <main id="app-main" class="app-main">
        <div class="wrap">
            <section class="app-content">
                <div class="row">
                    <div class="col-md-12 col-lg-8 offset-lg-2">
                        <div class="widget">
                            <header class="widget-header">
                                <h4 class="widget-title">Asignar Caja</h4>
                            </header><!-- .widget-header -->
                            <hr class="widget-separator">
                            <div class="widget-body">
                                <form method="POST" action="<?php echo e(url('supervisor/agent')); ?>/<?php echo e($id); ?>" enctype="multipart/form-data">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('PUT')); ?>

                                    <div class="form-group">
                                        <label for="name">Nombres:</label>
                                        <input type="text" name="name" value="<?php echo e($name); ?> <?php echo e($last_name); ?>" class="form-control" id="name" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="name">Cobro:</label>
                                        <input type="text" name="name" value="<?php echo e($wallet_name); ?>" class="form-control" id="name" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="base_number_current">Caja actual:</label>
                                        <input type="number" name="base_number_current" value="<?php echo e($base_current); ?>"  readonly class="form-control" id="base_number_current" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="base_number">Ingresar Dinero a Caja:</label>
                                        <input type="number" name="base_number" class="form-control" id="base_number" required>
                                        <p class="text-muted">La nueva caja se sumara con la caja actual</p>
                                    </div>
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-success btn-block btn-md">Guardar</button>
                                    </div>
                                </form>

                            </div><!-- .widget-body -->
                        </div><!-- .widget -->
                    </div><!-- END column -->
                </div><!-- .row -->
            </section>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\artur\Desktop\TRABAJOS\SISTEMA-PRESTAMO\sistema-prestamos\resources\views/supervisor_agent/edit.blade.php ENDPATH**/ ?>