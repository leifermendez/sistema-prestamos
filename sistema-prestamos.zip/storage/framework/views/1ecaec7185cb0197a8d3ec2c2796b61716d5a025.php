

<?php $__env->startSection('content'); ?>
    <!-- APP MAIN ==========-->
    <main id="app-main" class="app-main">
        <div class="wrap">
            <section class="app-content">
                <div class="row">
                    <div class="col-md-12 col-lg-8 offset-lg-2">
                        <div class="widget">
                            <header class="widget-header">
                                <h4 class="widget-title">Editar pago</h4>
                            </header><!-- .widget-header -->
                            <hr class="widget-separator">
                            <div class="widget-body">
                                <form method="POST" action="<?php echo e(url('supervisor/summary')); ?>/<?php echo e($id_summary); ?>" enctype="multipart/form-data">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('PUT')); ?>

                                    <div class="form-group">
                                        <label for="name">Nombres:</label>
                                        <input type="text" name="name" value ="<?php echo e($name); ?> <?php echo e($last_name); ?>" readonly class="form-control" id="name">
                                        <input type="hidden" name="id_wallet" value="<?php echo e($id_wallet); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="address">Barrio:</label>
                                        <input type="text" name="credit_id" value="<?php echo e($province); ?>" readonly class="form-control" id="address">
                                    </div>
                                    <div class="form-group">
                                        <label for="province">Credito:</label>
                                        <input type="text" name="province" value="<?php echo e($credit_id); ?>" readonly class="form-control" id="province">
                                    </div>
                                    <div class="form-group">
                                        <label for="amount">Valor:</label>
                                        <input type="text" name="amount" value="<?php echo e($amount_value); ?>" class="form-control" id="amount">
                                    </div>
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-success btn-block btn-md">Guardar</button>
                                    </div>
                                </form>

                            </div><!-- .widget-body -->
                        </div><!-- .widget -->
                    </div><!-- END column -->
                </div><!-- .row -->
            </section>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\artur\Desktop\TRABAJOS\SISTEMA-PRESTAMO\sistema-prestamos\resources\views/submenu/summary/edit.blade.php ENDPATH**/ ?>