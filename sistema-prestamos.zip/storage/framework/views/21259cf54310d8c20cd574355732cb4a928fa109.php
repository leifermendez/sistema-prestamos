

<?php $__env->startSection('content'); ?>
    <!-- APP MAIN ==========-->
    <main id="app-main" class="app-main">
        <div class="wrap">
            <section class="app-content">
                <div class="row">
                    <div class="col-md-12">

                        <div class="widget p-lg">
                            <h4 class="m-b-lg">Caja Actual</h4>
                            <div class="d-none d-lg-block d-xl-block d-md-block overflow-auto">
                                <table class="table supervisor-cash-table">
                                    <tbody>
                                            <tr>
                                                <th>Cobro</th>
                                                <th>Detalle</th>
                                                <th>Caja Actual Cierre</th>
                                            </tr> 
                                    
                                    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($client->name); ?></td>
                                            <td><?php echo e($client->created_at); ?></td>
                                            <td><?php echo e($client->base); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>

                            <!-- FOR MOBILE -->
                            <div class=" d-lg-none d-xl-none d-md-none">
                                <table class="table supervisor-cash-table">
                                    <tbody>
                                            <!-- <tr>
                                                <th>Cartera</th>
                                                <th>Detalle</th>
                                                <th>Valor inicial</th>
                                            </tr>  -->
                                    
                                    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($client->name); ?></td>
                                            <td><?php echo e($client->created_at); ?></td>
                                            <td><?php echo e($client->base); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>
                            <footer class="widget-footer">
                                <p class="text-success"><b>Total: </b> <?php echo e($sum); ?></p>
                            </footer>
                        </div><!-- .widget -->

                    </div>
                </div><!-- .row -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="widget p-lg">
                            <h4 class="m-b-lg">Historial Caja</h4>
                            <div class="d-none d-lg-block d-xl-block d-md-block overflow-auto">
                                <table class="table client-table">
                                    <tbody>
                                            <tr>
                                                <th>Fecha Año/Mes/Dia </th>
                                                <th>Cobro</th>
                                                <th>Caja</th>
                                            </tr>  
                                    
                                    <?php $__currentLoopData = $report; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($r->created_at); ?></td>
                                            <td><?php echo e($r->wallet_name); ?></td>
                                            <td><?php echo e($r->total); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>   
                            </div>

                            <!-- FOR MOBILE -->
                            <div class=" d-lg-none d-xl-none d-md-none">
                                <table class="table client-table">
                                    <tbody>
                                            <!-- <tr>
                                                <th>Fecha</th>
                                                <th>Saldo Base</th>
                                            </tr>   -->
                                    
                                    <?php $__currentLoopData = $report; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($r->created_at); ?></td>
                                            <td><?php echo e($r->total); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>   
                            </div>
                        </div><!-- .widget -->
                    </div>
                </div><!-- .row -->
            </section>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\artur\Desktop\TRABAJOS\SISTEMA-PRESTAMO\sistema-prestamos\resources\views/supervisor_cash/index.blade.php ENDPATH**/ ?>