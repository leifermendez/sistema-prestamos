

<?php $__env->startSection('content'); ?>
    <!-- APP MAIN ==========-->
    <main id="app-main" class="app-main">
        <div class="wrap">
            <section class="app-content d-none d-lg-block d-xl-block d-md-block">
                <div class="row">
                    <div class="col-md-12">
                        <div class="widget p-lg  overflow-auto">
                            <h4 class="m-b-lg">Usuarios</h4>
                            <table class="table admin-table">
                                <tbody>
                                        <tr>
                                            <th>ID</th>
                                            <th>Usuario</th>
                                            <th>Nombre</th>
                                            <th>Nivel</th>
                                            <th>Cartera</th>
                                            <th>Supervisor</th>
                                            <th></th>
                                    </div>
                                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($client->active_user=='enabled'): ?>
                                        <tr>
                                            <td><?php echo e($client->id); ?></td>
                                            <td><?php echo e($client->email); ?></td>
                                            <td><?php echo e($client->name); ?></td>
                                            <td><?php echo e($client->level); ?></td>
                                            <td><?php echo e($client->wallet_name); ?></td>
                                            <td><?php echo e($client->supervisor); ?></td>
                                            <td>
                                                <form action="<?php echo e(url('admin/user')); ?>/<?php echo e($client->id); ?>" method="POST"
                                                      class="pull-left px-1">
                                                    <?php echo e(csrf_field()); ?>

                                                    <?php echo e(method_field('DELETE')); ?>

                                                    <button type="submit" class="btn btn-danger btn-xs">Eliminar
                                                    </button>
                                                </form>



                                                <a href="<?php echo e(url('admin/user')); ?>/<?php echo e($client->id); ?>/edit"
                                                   class="btn btn-info btn-xs px-1">Editar</a>
                                                <?php if($client->level == 'supervisor'): ?>
                                                    <a href="<?php echo e(url('admin/user')); ?>/<?php echo e($client->id); ?>"
                                                       class="btn btn-warning btn-xs">Asignar agente</a>
                                                <?php endif; ?>

                                                <form action="<?php echo e(url('admin/session')); ?>/<?php echo e($client->id); ?>" method="POST"
                                                      class="pull-left px-1">
                                                    <?php echo e(csrf_field()); ?>

                                                    <?php echo e(method_field('PUT')); ?>

                                                    <button type="submit" class="btn btn-inverse btn-xs">Session
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div><!-- .widget -->
                    </div>
                </div><!-- .row -->
            </section>

            <!-- FOR MOBIL -->
            <section class="app-content d-lg-none d-xl-none d-md-none">
                <div class="row">
                    <div class="col-md-12">
                        <div class="widget p-lg  overflow-auto">
                            <h4 class="m-b-lg">Usuarios</h4>
                            <table class="table admin-table">
                                <tbody>
                                        <!-- <tr>
                                            <th>ID</th>
                                            <th>Usuario</th>
                                            <th>Nombre</th>
                                            <th>Nivel</th>
                                            <th>Cartera</th>
                                            <th>Supervisor</th>
                                            <th></th>
                                        </tr> -->
                                
                                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($client->active_user=='enabled'): ?>
                                        <tr class="pb-5">
                                            <td><?php echo e($client->id); ?></td>
                                            <td><?php echo e($client->email); ?></td>
                                            <td><?php echo e($client->name); ?></td>
                                            <td><?php echo e($client->level); ?></td>
                                            <td><?php echo e($client->wallet_name); ?></td>
                                            <td><?php echo e($client->supervisor); ?></td>
                                            <td>
                                                <form action="<?php echo e(url('admin/user')); ?>/<?php echo e($client->id); ?>" method="POST"
                                                      class="pull-left px-1">
                                                    <?php echo e(csrf_field()); ?>

                                                    <?php echo e(method_field('DELETE')); ?>

                                                    <button type="submit" class="btn btn-danger btn-xs">Eliminar
                                                    </button>
                                                </form>



                                                <a href="<?php echo e(url('admin/user')); ?>/<?php echo e($client->id); ?>/edit"
                                                   class="btn btn-info btn-xs px-1">Editar</a>
                                                <?php if($client->level == 'supervisor'): ?>
                                                    <a href="<?php echo e(url('admin/user')); ?>/<?php echo e($client->id); ?>"
                                                       class="btn btn-warning btn-xs">Asignar agente</a>
                                                <?php endif; ?>

                                                <form action="<?php echo e(url('admin/session')); ?>/<?php echo e($client->id); ?>" method="POST"
                                                      class="pull-left px-1">
                                                    <?php echo e(csrf_field()); ?>

                                                    <?php echo e(method_field('PUT')); ?>

                                                    <button type="submit" class="btn btn-inverse btn-xs">Session
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div><!-- .widget -->
                    </div>
                </div><!-- .row -->
            </section>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\artur\Desktop\TRABAJOS\SISTEMA-PRESTAMO\sistema-prestamos\resources\views/admin/index.blade.php ENDPATH**/ ?>