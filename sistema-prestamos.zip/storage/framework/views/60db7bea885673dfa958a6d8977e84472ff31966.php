

<?php $__env->startSection('content'); ?>
<!-- APP MAIN ==========-->
<main id="app-main" class="app-main">
    <div class="wrap">
        <section class="app-content">
            <div class="row">
                <div class="col-md-12 col-lg-8 offset-lg-2">
                    <?php if($message = Session::get('error')): ?>
                    <div class="alert alert-danger">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong><?php echo e($message); ?></strong>
                    </div>
                    <?php endif; ?>
                    <div class="widget">
                        <header class="widget-header">
                            <h4 class="widget-title">Clientes que no pagaron por días</h4>
                        </header><!-- .widget-header -->
                        <hr class="widget-separator">
                        <div class="widget-body">
                            <form method="POST" action="<?php echo e(url('not-pay')); ?>" enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                                <div class="form-group">
                                    <label for="nit_number"> Fecha inicial:</label>
                                    <input type="text" name="date_start" class="form-control datepicker-trigger"
                                        id="date_start" required>
                                </div>
                                <div class="form-group">
                                    <label for="nit_number"> Fecha final:</label>
                                    <input type="text" name="date_end" class="form-control datepicker-trigger"
                                        id="date_end" required>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-success btn-block btn-md">Buscar</button>
                                </div>
                            </form>

                        </div><!-- .widget-body -->
                    </div><!-- .widget -->
                </div><!-- END column -->
            </div><!-- .row -->
        </section>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\artur\Desktop\TRABAJOS\SISTEMA-PRESTAMO\sistema-prestamos\resources\views/not-payments/create.blade.php ENDPATH**/ ?>