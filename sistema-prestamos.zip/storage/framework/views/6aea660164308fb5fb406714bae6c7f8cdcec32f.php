

<?php $__env->startSection('content'); ?>
<!-- APP MAIN ==========-->
<main id="app-main" class="app-main">
  <div class="wrap">
    <section class="app-content">
      <div class="row">
        <div class="col-md-12">
          <div class="widget p-lg">
            <a href="<?php echo e(url('export')); ?> " class="btn btn-sm btn-primary float-right ">Exportar
              Excel</a>
            <h4 class="m-b-lg">Clientes que no pagaron</h4>

            <div class="d-none d-lg-block d-xl-block">
              <table class="table agente-not-payments-table">
                <thead>
                <tr>
                  <th>Cliente</th>
                  <th>Lunes</th>
                  <th>Martes</th>
                  <th>Míercoles</th>
                  <th>Jueves</th>
                  <th>Viernes</th>
                  <th>Sábado</th>
                  <th>Domingo</th>
                </tr>
                </thead>

                <tbody>
                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                  <tr>
                    <td><?php echo e($client->name); ?> <?php echo e($client->last_name); ?></td>
                    <td>
                    <span class="badge <?php echo e($client->summary_day['Monday']> 0 ? 'badge-success': 'badge-danger'); ?>">
                      <?php echo e($client->summary_day['Monday'] > 0 ?  $client->summary_day['Monday'] : $client->summary_day['Monday']); ?>

                    </span>
                    </td>
                    <td>
                    <span class="badge <?php echo e($client->summary_day['Tuesday']> 0 ? 'badge-success': 'badge-danger'); ?>">

                      <?php echo e($client->summary_day['Tuesday'] > 0 ?  $client->summary_day['Tuesday'] : $client->summary_day['Tuesday']); ?>

                    </span>
                    </td>
                    <td>
                    <span class="badge <?php echo e($client->summary_day['Wednesday']> 0 ? 'badge-success': 'badge-danger'); ?>">
                      <?php echo e($client->summary_day['Wednesday'] > 0 ?  $client->summary_day['Wednesday'] : $client->summary_day['Wednesday']); ?>

                    </span>
                    </td>
                    <td>
                    <span class="badge <?php echo e($client->summary_day['Thursday']> 0 ? 'badge-success': 'badge-danger'); ?>   ">
                      <?php echo e($client->summary_day['Thursday'] > 0 ?  $client->summary_day['Thursday'] : $client->summary_day['Thursday']); ?>


                    </span>
                    </td>
                    <td>
                    <span class="badge <?php echo e($client->summary_day['Friday']> 0 ? 'badge-success': 'badge-danger'); ?>   ">
                      <?php echo e($client->summary_day['Friday'] > 0 ?  $client->summary_day['Friday'] : $client->summary_day['Friday']); ?>

                    </span>
                    </td>
                    <td>
                    <span class="badge <?php echo e($client->summary_day['Saturday']> 0 ? 'badge-success': 'badge-danger'); ?>   ">
                      <?php echo e($client->summary_day['Saturday'] > 0 ?  $client->summary_day['Saturday'] : $client->summary_day['Saturday']); ?>

                    </span>
                    </td>
                    <td>
                    <span class="badge <?php echo e($client->summary_day['Sunday']> 0 ? 'badge-success': 'badge-danger'); ?>   ">
                      <?php echo e($client->summary_day['Sunday'] > 0 ?  $client->summary_day['Sunday'] : $client->summary_day['Sunday']); ?>

                    </span>
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>


            <div class="d-sm-block d-lg-none">
              <table class="table agente-not-payments-table">
                <thead class="d-none">
                  <tr>
                    <th>Cliente</th>
                    <th>Lunes</th>
                    <th>Martes</th>
                    <th>Míercoles</th>
                    <th>Jueves</th>
                    <th>Viernes</th>
                    <th>Sábado</th>
                    <th>Domingo</th>
                  </tr>
                </thead>

                <tbody>
                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($client->name); ?> <?php echo e($client->last_name); ?></td>
                    <td>
                    <span class="badge <?php echo e($client->summary_day['Monday']> 0 ? 'badge-success': 'badge-danger'); ?>">
                      <?php echo e($client->summary_day['Monday'] > 0 ?  $client->summary_day['Monday'] : $client->summary_day['Monday']); ?>

                    </span>
                    </td>
                    <td>
                    <span class="badge <?php echo e($client->summary_day['Tuesday']> 0 ? 'badge-success': 'badge-danger'); ?>">

                      <?php echo e($client->summary_day['Tuesday'] > 0 ?  $client->summary_day['Tuesday'] : $client->summary_day['Tuesday']); ?>

                    </span>
                    </td>
                    <td>
                    <span class="badge <?php echo e($client->summary_day['Wednesday']> 0 ? 'badge-success': 'badge-danger'); ?>">
                      <?php echo e($client->summary_day['Wednesday'] > 0 ?  $client->summary_day['Wednesday'] : $client->summary_day['Wednesday']); ?>

                    </span>
                    </td>
                    <td>
                    <span class="badge <?php echo e($client->summary_day['Thursday']> 0 ? 'badge-success': 'badge-danger'); ?>   ">
                      <?php echo e($client->summary_day['Thursday'] > 0 ?  $client->summary_day['Thursday'] : $client->summary_day['Thursday']); ?>


                    </span>
                    </td>
                    <td>
                    <span class="badge <?php echo e($client->summary_day['Friday']> 0 ? 'badge-success': 'badge-danger'); ?>   ">
                      <?php echo e($client->summary_day['Friday'] > 0 ?  $client->summary_day['Friday'] : $client->summary_day['Friday']); ?>

                    </span>
                    </td>
                    <td>
                    <span class="badge <?php echo e($client->summary_day['Saturday']> 0 ? 'badge-success': 'badge-danger'); ?>   ">
                      <?php echo e($client->summary_day['Saturday'] > 0 ?  $client->summary_day['Saturday'] : $client->summary_day['Saturday']); ?>

                    </span>
                    </td>
                    <td>
                    <span class="badge <?php echo e($client->summary_day['Sunday']> 0 ? 'badge-success': 'badge-danger'); ?>   ">
                      <?php echo e($client->summary_day['Sunday'] > 0 ?  $client->summary_day['Sunday'] : $client->summary_day['Sunday']); ?>

                    </span>
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>


          </div><!-- .widget -->
        </div>
      </div><!-- .row -->
    </section>
  </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\artur\Desktop\TRABAJOS\LEANGASOFTWARE\SISTEMA-PRESTAMO\sistema-prestamos\resources\views/not-payments/index.blade.php ENDPATH**/ ?>