

<?php $__env->startSection('content'); ?>

<!-- APP MAIN ==========-->
<main id="app-main" class="app-main">
    <div class="wrap">
        <section class="app-content">
            <div class="row">
                <div class="col-md-12">
                    <div class="widget p-lg overflow-auto">
                        <h4 class="m-b-lg">Clientes y Creditos</h4>
                        <button class="btn btn-primary float-left" id="changeList">Ordenar lista</button>
                        <button class="btn btn-primary float-left d-none  mb-4" id="seeList">Ver lista</button>
                        <?php if(app('request')->input('hide')): ?>
                        <div class="alert alert-warning alert-custom alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span
                                    aria-hidden="true">×</span></button>
                            <h4 class="alert-title">Informacion</h4>
                            <p>Orden cambiado por encima/debajo de un usuario que saltaste el dia de hoy.</p>
                        </div>
                        <?php endif; ?>

                        <table class="table agente-route-table">
                            <thead>
                                <tr>
                                    <th class="hidden">Orden</th>
                                    <th># Credito</th>
                                    <th>Nombres</th>
                                    <th>Cuotas Atrasadas</th>
                                    <th>Cuota diaria</th>
                                    <th>Valor</th>
                                    <th>Saldo</th>
                                    <th>Ultimo pago</th>
                                    <th>Tipo de Negocio</th>
                                    <th>Status</th>
                                    <th></th>
                                </tr>
                            </thead>

                            <tbody class="connectedSortable" id="complete-item-drop">
                                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr id="td_<?php echo e($client->id); ?>" class="item" item-id="<?php echo e($client->id); ?>">
                                    <td class="hidden"><?php echo e($client->order_list); ?></td>
                                    <td><?php echo e($client->id); ?></td>
                                    <td><?php echo e($client->user->name); ?> <?php echo e($client->user->last_name); ?></td>
                                    <td><?php echo e($client->days_rest); ?></td>
                                    <td><?php echo e($client->quote); ?></td>
                                    <td><?php echo e($client->amount_total); ?></td>
                                    <td id="saldo"><?php echo e($client->saldo); ?></td>
                                    <?php if($client->last_pay): ?>
                                    <td><?php echo e($client->last_pay->created_at); ?></td>
                                    <?php else: ?>
                                    <td>No hay pagos</td>
                                    <?php endif; ?>
                                    <td><?php echo e($client->user->province); ?></td>
                                    <td>
                                        <?php if($client->user->status=='good'): ?>
                                        <span class="badge-info badge">BUENO</span>
                                        <?php elseif($client->user->status=='bad'): ?>
                                        <span class="badge-danger badge">MALO</span>
                                        <?php endif; ?>

                                    </td>
                                    <td>
                                        <a href="<?php echo e(url('route')); ?>/<?php echo e($client->order_list); ?>/edit?id_credit=<?php echo e($client->id); ?>&direction=up"
                                            class="btn btn-default btn-xs arw-up btn-center-arrow"><i
                                                class="fa fa-arrow-up"></i></a>
                                        <a href="<?php echo e(url('payment')); ?>/<?php echo e($client->id); ?>"
                                            class="btn btn-success btn-xs hidden"><i class="fa fa-money"></i> Pagar</a>

                                        <a href="#openModal<?php echo e($client->id); ?>" class="btn btn-success btn-xs"> Pagar</a>

                                        <?php echo $__env->make('route.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                        <a href="<?php echo e(url('route')); ?>/" id_user="<?php echo e($client->id_user); ?>"
                                            id_credit="<?php echo e($client->id); ?>"
                                            class="btn btn-warning btn-xs ajax-btn btn-pagar"><i
                                                class="fa fa-archive "></i> Saltar</a>
                                        <form action="<?php echo e(url('pending-pay')); ?>" method="POST" class="pull-left px-1">
                                            <?php echo e(csrf_field()); ?>

                                            <input type="hidden" name="id_credit" value="<?php echo e($client->id); ?>">
                                            <button type="submit" class="btn btn-inverse btn-xs">
                                                Pendiente
                                            </button>
                                        </form>
                                        <a href="<?php echo e(url('summary')); ?>?id_credit=<?php echo e($client->id); ?>"
                                            class="btn btn-info btn-xs hidden"><i class="fa fa-history"></i> Ver</a>
                                        <a href="<?php echo e(url('route')); ?>/<?php echo e($client->order_list); ?>/edit?id_credit=<?php echo e($client->id); ?>&direction=down"
                                            class="btn btn-default btn-xs arw-down btn-center-arrow"><i
                                                class="fa fa-arrow-down"></i></a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <table class="table agente-route-table" id="pending">
                            <thead>
                                <tr>
                                    <th># Credito</th>
                                    <th>Nombres</th>
                                    <th>Status</th>
                                    <th></th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php $__currentLoopData = $pending; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr id="td_<?php echo e($client->id); ?>">
                                    <td><?php echo e($client->id); ?></td>
                                    <td><?php echo e($client->id); ?></td>
                                    <td><?php echo e($client->id); ?></td>
                                    <td><?php echo e($client->user_name); ?> <?php echo e($client->user_last_name); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                    </div><!-- .widget -->
                </div>
            </div><!-- .row -->
        </section>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\artur\Desktop\TRABAJOS\SISTEMA-PRESTAMO\sistema-prestamos\resources\views/route/index.blade.php ENDPATH**/ ?>