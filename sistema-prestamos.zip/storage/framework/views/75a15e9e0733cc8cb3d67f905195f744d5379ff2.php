

<?php $__env->startSection('content'); ?>
    <!-- APP MAIN ==========-->
    <main id="app-main" class="app-main">
        <div class="wrap">
            <section class="app-content">
                <div class="row">
                    <div class="col-md-12">
                        <div class="widget p-lg">
                            <h4 class="m-b-lg">Clientes</h4>
                            <table class="table supervisor-clientes-table">
                                    <thead class="d-none-edit">
                                    <tr>
                                        <th>Nombres</th>
                                        <th>Tipo de Negocio</th>
                                        <th>Total Creditos</th> 
                                        <th>Pagados</th>
                                        <th>Vigentes</th>
                                        <th>Tipo</th>
                                        <th></th>
                                    </tr>
                                    </thead>
                                
                                <tbody>
                                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($client->name); ?> <?php echo e($client->last_name); ?></td>
                                        <td><?php echo e($client->province); ?></td>
                                        <td><?php echo e($client->total_credit); ?></td>
                                        <td><?php echo e($client->credit_close); ?></td>
                                        <td><?php echo e($client->credit_inprogress); ?></td>
                                        <td>
                                            <?php if($client->status=='good'): ?>
                                                <span class="badge-info badge">BUENO</span>
                                            <?php elseif($client->status=='bad'): ?>
                                                <span class="badge-danger badge">MALO</span>
                                            <?php endif; ?>

                                        </td>
                                        <td>
                                            <a href="<?php echo e(url('supervisor/client')); ?>/<?php echo e($client->id_user); ?>/edit" class="btn btn-warning btn-xs">Editar</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div><!-- .widget -->
                    </div>
                </div><!-- .row -->
            </section>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\artur\Desktop\TRABAJOS\LEANGASOFTWARE\SISTEMA-PRESTAMO\sistema-prestamos\resources\views/supervisor_client/index.blade.php ENDPATH**/ ?>