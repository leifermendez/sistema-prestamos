

<?php $__env->startSection('content'); ?>
    <!-- APP MAIN ==========-->
    <main id="app-main" class="app-main">
        <div class="wrap">
            <section class="app-content">
                <div class="row">
                    <div class="col-md-12">
                        <div class="widget p-lg">
                            <h4 class="m-b-lg">Pagos</h4>
                            <form class="container" action="<?php echo e(url('supervisor/graph')); ?>" method="POST">
                                <?php echo e(csrf_field()); ?>

                                <div class="form-group">
                                    <label for="payment_number">Cobrador:</label>
                                    <select name="agent" class="form-control" id="agent">
                                        <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($client->id); ?>">
                                                <?php echo e($client->name); ?> <?php echo e($client->last_name); ?>

                                                - <?php echo e($client->wallet_name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                </div>
                                <div class="row align-items-end">
                                    <div class="col-sm-4">
                                        <label for="nit_number"> Fecha Inicial:</label>
                                        <input type="text" name="date_start"  class="form-control datepicker-trigger" id="date_start" required>
                                    </div>
                                    <div class="col-sm-4">
                                        <label for="nit_number"> Fecha Final:</label>
                                        <input type="text" name="date_end"  class="form-control datepicker-trigger" id="date_end" required>
                                    </div>
                                    <div class="col-sm-4">
                                        <button class="btn btn-info hidden" type="submit">Buscar</button>
                                        <a href="<?php echo e(url('supervisor/graph?type=default')); ?>" class="btn btn-dark">Regresar</a>
                                    </div>
                                </div>
                                <input type="hidden" name="type" id="type" value="payment">
                            </form>
                            <br class="clearfix">

                            <div class="container">
                                <?php if(count($data)>0): ?>
                                    <input type="hidden" name="dataGraph" id="dataGraph" value="<?php echo e(json_encode($data)); ?>">


                                    <div class="pt-4 px-1 container d-flex justify-content-center">
                                        <div style=" position: relative;
                                              margin: auto;
                                              height: 30vh;
                                              width: 100vw;">
                                            <canvas id="dataDays" width="200" height="100"></canvas>
                                        </div>
                                    </div>

                                    
                                    <div class="row pt-5" id="graphs">
                                        <div class="col-sm-6" style=" position: relative;
                                              margin: auto;
                                              height: 30vh;
                                              width: 100vw;">
                                            <canvas id="dataItems" width="200" height="100"></canvas>
                                        </div>
                                        <div class="col-sm-6" style=" position: relative;
                                              margin: auto;
                                              height: 30vh;
                                              width: 100vw;">
                                            <canvas id="dataAmount" width="200" height="100"></canvas>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div><!-- .widget -->
                    </div>
                </div><!-- .row -->
            </section>
        </div>
    </main>
    <script>
        function load() {
            const dataGraph = JSON.parse(document.getElementById('dataGraph').value);

            graphicsDays(
                dataGraph.dataDays.data,
                dataGraph.dataDays.labels,
                dataGraph.dataDays.total,
                'Pagos por día',
                'dataDays'
            );

            graphics(
                [dataGraph.dataItems.thisWeekend, dataGraph.dataItems.lastWeekend],
                [dataGraph.thisWeekend, dataGraph.lastWeekend],
                'Cantidad de pagos',
                'dataItems'
            );

            graphics(
                [dataGraph.dataAmount.thisWeekend, dataGraph.dataAmount.lastWeekend],
                [dataGraph.thisWeekend, dataGraph.lastWeekend],
                'Pagos por rango',
                'dataAmount'
            );
        }
        setTimeout(function () {
            window.onload = load()
        }, 2000)
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\artur\Desktop\TRABAJOS\SISTEMA-PRESTAMO\sistema-prestamos\resources\views/graph/payment.blade.php ENDPATH**/ ?>