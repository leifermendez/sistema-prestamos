

<?php $__env->startSection('content'); ?>
    <!-- APP MAIN ==========-->
    <main id="app-main" class="app-main">
        <div class="wrap">
            <section class="app-content">
                <div class="row">
                    <div class="col-md-12 col-lg-8 offset-lg-2">
                        <div class="widget">
                            <header class="widget-header">
                                <h4 class="widget-title">Cierre</h4>
                            </header><!-- .widget-header -->
                            <hr class="widget-separator">
                            <div class="widget-body">
                                <form method="GET" action="<?php echo e(url('history')); ?>" enctype="multipart/form-data">
                                    <div class="form-group">
                                        <label for="base_amount">Base del cobro:</label>
                                        <input type="text" name="base_amount" value="<?php echo e(($base) ? $base : 'No existe cierre del día'); ?>" readonly class="form-control" id="base_amount" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="base_amount">Recaudo:</label>
                                        <input type="text" name="today" value="<?php echo e(($base) ? $today_amount : 'No existe cierre del día'); ?>" readonly class="form-control" id="base_amount" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="base_amount">Ventas:</label>
                                        <input type="text" name="today" value="<?php echo e(($base) ? $today_sell : 'No existe cierre del día'); ?>" readonly class="form-control" id="base_amount" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="base_amount">Gastos:</label>
                                        <input type="text" name="today" value="<?php echo e(($base) ? $bills : 'No existe cierre del día'); ?>" readonly class="form-control" id="base_amount" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="base_amount">Total Cuadre:</label>
                                        <input type="text" name="today" value="<?php echo e(($base) ? $total : 'No existe cierre del día'); ?>" readonly class="form-control" id="base_amount" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="base_amount">Efectividad:</label>
                                        <input type="text" name="today" value="<?php echo e(($base) ? $average : 'No existe cierre del día'); ?>" readonly class="form-control" id="base_amount" required>
                                    </div>
                                </form>

                            </div><!-- .widget-body -->
                        </div><!-- .widget -->
                    </div><!-- END column -->
                </div><!-- .row -->
                <div class="col-lg-12 text-right">
                    <a href="<?php echo e(url('supervisor/review/')); ?>/<?php echo e($id_wallet); ?>" class="btn btn-inverse"><i class="fa fa-arrow-left"></i> Regresar</a>
                </div>
            </section>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\artur\Desktop\TRABAJOS\SISTEMA-PRESTAMO\sistema-prestamos\resources\views/submenu/close/show.blade.php ENDPATH**/ ?>