

<?php $__env->startSection('content'); ?>
    <!-- APP MAIN ==========-->
    <main id="app-main" class="app-main">
        <div class="wrap">
            <section class="app-content">
                <div class="row">
                    <div class="col-md-12">
                        <div class="widget p-lg">
                            <h4 class="m-b-lg">Gastos</h4>
                            <form class="form-inline" action="<?php echo e(url('supervisor/menu/bill')); ?>/<?php echo e($id); ?>" method="GET">
                                <div class="form-group">
                                    <label for="nit_number"> Fecha Inicial:</label>
                                    <input type="text" name="date_start"  class="form-control datepicker-trigger" id="date_start" required>
                                </div>
                                <div class="form-group">
                                    <label for="nit_number"> Fecha Final:</label>
                                    <input type="text" name="date_end"  class="form-control datepicker-trigger" id="date_end" required>
                                </div>

                                <button class="btn btn-info" type="submit">Buscar</button>

                            </form>
                            <br class="clearfix">
                            <div class="d-none d-lg-block d-xl-block d-md-block overflow-auto">
                                <table class="table supervisor-gastos-table">
                                    <tbody>
                                            <tr>
                                                <th>Cartera</th>
                                                <th>Fecha</th>
                                                <th>Agente</th>

                                                <th>Valor</th>
                                                <th>Detalle</th>
                                                <th></th>
                                            </tr>
                                    
                                    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($client->wallet_name); ?></td>
                                            <td><?php echo e($client->created_at); ?></td>
                                            <td><?php echo e($client->user_name); ?> <?php echo e($client->user_lastname); ?></td>

                                            <td><?php echo e($client->amount); ?></td>
                                            <td><?php echo e($client->description); ?></td>
                                            <td></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>

                            <!-- FOR MOBIL -->
                            <div class=" d-lg-none d-xl-none d-md-none">
                                <table class="table supervisor-gastos-table">
                                    <tbody>
                                            <!-- <tr>
                                                <th>Cartera</th>
                                                <th>Fecha</th>
                                                <th>Agente</th>

                                                <th>Valor</th>
                                                <th>Detalle</th>
                                                <th></th>
                                            </tr> -->
                                    
                                    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($client->wallet_name); ?></td>
                                            <td><?php echo e($client->created_at); ?></td>
                                            <td><?php echo e($client->user_name); ?> <?php echo e($client->user_lastname); ?></td>

                                            <td><?php echo e($client->amount); ?></td>
                                            <td><?php echo e($client->description); ?></td>
                                            <td></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>
                            
                            <footer class="widget-footer">
                                <p><b>Total: </b><span class="text-success"><?php echo e($total); ?></span></p>
                            </footer>
                        </div><!-- .widget -->
                    </div>
                </div><!-- .row -->
                <div class="col-lg-12 text-right">
                    <a href="<?php echo e(url('supervisor/review/')); ?>/<?php echo e($id); ?>" class="btn btn-inverse"><i class="fa fa-arrow-left"></i> Regresar</a>
                </div>
            </section>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\artur\Desktop\TRABAJOS\SISTEMA-PRESTAMO\sistema-prestamos\resources\views/submenu/bill/index.blade.php ENDPATH**/ ?>