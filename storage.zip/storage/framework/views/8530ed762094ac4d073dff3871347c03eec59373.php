

<?php $__env->startSection('content'); ?>
    <!-- APP MAIN ==========-->
    <main id="app-main" class="app-main">
        <div class="wrap">
            <section class="app-content">
                <div class="row">
                    <div class="col-md-12">
                        <div class="widget p-lg">
                            <h4 class="m-b-lg">Movimiento del personal</h4>
                            <form action="<?php echo e(url('admin/audit')); ?>" method="GET">
                                <div class="d-flex justify-content-around align-items-center">
                                    <div>
                                        <label for="nit_number"> Fecha Inicial:</label>
                                        <input type="text" name="date_start"  class="form-control datepicker-trigger" id="date_start" required>
                                    </div>
                                    <div>
                                        <label for="nit_number"> Fecha Final:</label>
                                        <input type="text" name="date_end"  class="form-control datepicker-trigger" id="date_end" required>
                                    </div>

                                    <button class="btn btn-info hidden" type="submit">Buscar</button>
                                </div>
                            </form>
                            <br class="clearfix">
                            <div class="container">
                                <?php $__currentLoopData = $audits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $audit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="card shadow mt-3">
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="col-6">
                                                    <p><?php echo e($audit->user_name); ?> <?php echo e($audit->user_last_name); ?>

                                                        &nbsp;&nbsp;||&nbsp;&nbsp;
                                                        <?php if($audit->event === 'create'): ?>
                                                            Creó: <?php echo e($audit->type); ?>

                                                        <?php endif; ?>

                                                        <?php if($audit->event === 'delete'): ?>
                                                            Eliminó: <?php echo e($audit->type); ?>

                                                        <?php endif; ?>

                                                        <?php if($audit->event === 'update'): ?>
                                                            Editó: <?php echo e($audit->type); ?>

                                                        <?php endif; ?>
                                                    </p>
                                                </div>
                                                <div class="col-6 text-right">
                                                    <p class="m-0"><?php echo e(date_format($audit->created_at, "d/m/Y")); ?></p>
                                                    <small><?php echo e($audit->user_level); ?></small>
                                                </div>
                                            </div>
                                            <?php if($audit->event === 'create'): ?>
                                                <div class="alert alert-success" role="alert">
                                                    <ul>
                                                        <?php $__currentLoopData = json_decode($audit->data); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <li>
                                                                <?php echo e($key); ?>: &nbsp; <?php echo e($data); ?>

                                                            </li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </ul>

                                                </div>
                                            <?php endif; ?>

                                            <?php if($audit->event === 'delete'): ?>
                                                <div class="alert alert-danger" role="alert">

                                                    <ul>
                                                        <?php $__currentLoopData = json_decode($audit->data); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <li>
                                                                <?php echo e($key); ?>: &nbsp; <?php echo e($data); ?>

                                                            </li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </ul>
                                                </div>
                                            <?php endif; ?>

                                            <?php if($audit->event === 'update'): ?>
                                                <div class="alert alert-primary" role="alert">

                                                    <ul>
                                                        <?php $__currentLoopData = json_decode($audit->data); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <li>
                                                                <?php echo e($key); ?>: &nbsp; <?php echo e($data); ?>

                                                            </li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </ul>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div><!-- .widget -->
                    </div>
                </div><!-- .row -->
            </section>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\artur\Desktop\TRABAJOS\SISTEMA-PRESTAMO\sistema-prestamos\resources\views/audit/index.blade.php ENDPATH**/ ?>