<div id="openModal<?php echo e($client->id); ?>" class="modalDialog">
    <div>
        <a href="#close" title="Close" class="close">X</a>
        <h4 class="widget-title">Abono de cuota</h4>

        <form method="POST" class="payment-create" action="<?php echo e(url('summary')); ?>" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label for="name">Nombres:</label>
                <input type="text" name="name" value ="<?php echo e($client->user->name); ?> <?php echo e($client->user->last_name); ?>" readonly class="form-control" id="name">
            </div>
            <input type="hidden" name="rev" value="<?php echo e(app('request')->input('rev')); ?>">
            <div class="form-group">
                <label for="address">Número de credito:</label>
                <input type="text" name="credit_id" value="<?php echo e($client->id); ?>" readonly class="form-control" id="address">
            </div>
            <div class="form-group">
                <label for="province">Valor de venta:</label>
                <input type="text" name="province" value="<?php echo e($client->amount_total); ?> en <?php echo e($client->payment_number); ?> cuotas" readonly class="form-control" id="province">
            </div>
            <div class="form-group">
                <label for="phone">Pagado:</label>
                <input type="tel" name="phone" value="<?php echo e($client->positive); ?>" readonly class="form-control" id="phone">
            </div>
            <div class="form-group">
                <label for="phone">Saldo:</label>
                <input type="tel" name="phone" value="<?php echo e($client->rest); ?>" readonly class="form-control" id="phone">
            </div>
            <div class="form-group">
                <label for="amount">Valor de cuota:</label>
                <input type="text" readonly value="<?php echo e($client->payment_quote); ?>" class="form-control" id="amount1">
            </div>
            <div class="form-group">
                <label for="amount">Cuotas pagadas:</label>
                <input type="text" readonly value="<?php echo e($client->payment_done); ?>" class="form-control" id="amount2">
            </div>
            <div class="form-group">
                <label for="amount">Valor de abono:</label>
                <input type="number" step="any" min="1" max="<?php echo e($client->rest); ?>" value="<?php echo e(($client->rest < $client->payment_quote) ? $client->rest : $client->payment_quote); ?>" name="amount" class="form-control" id="amount">
            </div>
            <div class="form-group">
                <button type="submit" <?php echo e(($client->rest<1) ? 'disabled': ''); ?> class="btn btn-success btn-block btn-md">Guardar pago</button>
            </div>
        </form>
    </div>
</div><?php /**PATH C:\Users\artur\Desktop\TRABAJOS\SISTEMA-PRESTAMO\sistema-prestamos\resources\views/route/modal.blade.php ENDPATH**/ ?>